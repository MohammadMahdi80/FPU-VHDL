/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "E:/lessons/Term-01-1/Digital/HW/HW5/FPU1/tb.vhd";
extern char *IEEE_P_3564397177;
extern char *STD_TEXTIO;

void ieee_p_3564397177_sub_1281154728_91900896(char *, char *, char *, char *, char *, unsigned char , int );


static void work_a_1985558087_2372691052_p_0(char *t0)
{
    char t5[16];
    char t13[32];
    char t14[32];
    char t15[32];
    char t16[32];
    char t17[32];
    char t18[32];
    char t19[32];
    char t20[32];
    char t21[32];
    char t22[32];
    char t23[32];
    char t24[32];
    char t25[32];
    char t26[32];
    char t27[32];
    char t28[32];
    char t29[32];
    char t30[32];
    char t31[32];
    char t32[32];
    char t33[32];
    char t34[32];
    char t35[32];
    char t36[32];
    char t37[32];
    char t38[32];
    char t39[32];
    char t40[32];
    char t41[32];
    char t42[32];
    char t43[32];
    char t44[32];
    char t45[32];
    char t46[32];
    char t47[32];
    char t48[32];
    char t49[32];
    char t50[32];
    char t51[32];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t6;
    char *t7;
    int t8;
    unsigned int t9;
    int64 t10;
    char *t11;
    char *t12;

LAB0:    t1 = (t0 + 2912U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(50, ng0);
    t2 = (t0 + 1976U);
    t3 = (t0 + 6744);
    t6 = (t5 + 0U);
    t7 = (t6 + 0U);
    *((int *)t7) = 1;
    t7 = (t6 + 4U);
    *((int *)t7) = 12;
    t7 = (t6 + 8U);
    *((int *)t7) = 1;
    t8 = (12 - 1);
    t9 = (t8 * 1);
    t9 = (t9 + 1);
    t7 = (t6 + 12U);
    *((unsigned int *)t7) = t9;
    std_textio_file_open1(t2, t3, t5, (unsigned char)1);
    xsi_set_current_line(52, ng0);
    t10 = (100 * 1000LL);
    t2 = (t0 + 2720);
    xsi_process_wait(t2, t10);

LAB6:    *((char **)t1) = &&LAB7;

LAB1:    return;
LAB4:    xsi_set_current_line(54, ng0);
    t2 = (t0 + 6756);
    t4 = (t0 + 4168);
    t6 = (t4 + 56U);
    t7 = *((char **)t6);
    t11 = (t7 + 56U);
    t12 = *((char **)t11);
    memcpy(t12, t2, 32U);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(55, ng0);
    t2 = (t0 + 6788);
    t4 = (t0 + 4232);
    t6 = (t4 + 56U);
    t7 = *((char **)t6);
    t11 = (t7 + 56U);
    t12 = *((char **)t11);
    memcpy(t12, t2, 32U);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(56, ng0);
    t10 = (100 * 1000LL);
    t2 = (t0 + 2720);
    xsi_process_wait(t2, t10);

LAB10:    *((char **)t1) = &&LAB11;
    goto LAB1;

LAB5:    goto LAB4;

LAB7:    goto LAB5;

LAB8:    xsi_set_current_line(57, ng0);
    t2 = (t0 + 2720);
    t3 = (t0 + 2256U);
    t4 = (t0 + 1032U);
    t6 = *((char **)t4);
    memcpy(t13, t6, 32U);
    t4 = (t0 + 6512U);
    ieee_p_3564397177_sub_1281154728_91900896(IEEE_P_3564397177, t2, t3, t13, t4, (unsigned char)0, 0);
    xsi_set_current_line(57, ng0);
    t2 = (t0 + 2720);
    t3 = (t0 + 2256U);
    t4 = (t0 + 1192U);
    t6 = *((char **)t4);
    memcpy(t14, t6, 32U);
    t4 = (t0 + 6528U);
    ieee_p_3564397177_sub_1281154728_91900896(IEEE_P_3564397177, t2, t3, t14, t4, (unsigned char)0, 0);
    xsi_set_current_line(57, ng0);
    t2 = (t0 + 2720);
    t3 = (t0 + 2256U);
    t4 = (t0 + 1352U);
    t6 = *((char **)t4);
    memcpy(t15, t6, 32U);
    t4 = (t0 + 6544U);
    ieee_p_3564397177_sub_1281154728_91900896(IEEE_P_3564397177, t2, t3, t15, t4, (unsigned char)0, 0);
    xsi_set_current_line(57, ng0);
    t2 = (t0 + 2720);
    t3 = (t0 + 2256U);
    t4 = (t0 + 6820);
    t7 = (t5 + 0U);
    t11 = (t7 + 0U);
    *((int *)t11) = 1;
    t11 = (t7 + 4U);
    *((int *)t11) = 8;
    t11 = (t7 + 8U);
    *((int *)t11) = 1;
    t8 = (8 - 1);
    t9 = (t8 * 1);
    t9 = (t9 + 1);
    t11 = (t7 + 12U);
    *((unsigned int *)t11) = t9;
    std_textio_write7(STD_TEXTIO, t2, t3, t4, t5, (unsigned char)0, 0);
    xsi_set_current_line(57, ng0);
    t2 = (t0 + 2720);
    t3 = (t0 + 1976U);
    t4 = (t0 + 2256U);
    std_textio_writeline(STD_TEXTIO, t2, t3, t4);
    xsi_set_current_line(59, ng0);
    t10 = (100 * 1000LL);
    t2 = (t0 + 2720);
    xsi_process_wait(t2, t10);

LAB14:    *((char **)t1) = &&LAB15;
    goto LAB1;

LAB9:    goto LAB8;

LAB11:    goto LAB9;

LAB12:    xsi_set_current_line(61, ng0);
    t2 = (t0 + 6828);
    t4 = (t0 + 4168);
    t6 = (t4 + 56U);
    t7 = *((char **)t6);
    t11 = (t7 + 56U);
    t12 = *((char **)t11);
    memcpy(t12, t2, 32U);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(62, ng0);
    t2 = (t0 + 6860);
    t4 = (t0 + 4232);
    t6 = (t4 + 56U);
    t7 = *((char **)t6);
    t11 = (t7 + 56U);
    t12 = *((char **)t11);
    memcpy(t12, t2, 32U);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(63, ng0);
    t10 = (100 * 1000LL);
    t2 = (t0 + 2720);
    xsi_process_wait(t2, t10);

LAB18:    *((char **)t1) = &&LAB19;
    goto LAB1;

LAB13:    goto LAB12;

LAB15:    goto LAB13;

LAB16:    xsi_set_current_line(64, ng0);
    t2 = (t0 + 2720);
    t3 = (t0 + 2256U);
    t4 = (t0 + 1032U);
    t6 = *((char **)t4);
    memcpy(t16, t6, 32U);
    t4 = (t0 + 6512U);
    ieee_p_3564397177_sub_1281154728_91900896(IEEE_P_3564397177, t2, t3, t16, t4, (unsigned char)0, 0);
    xsi_set_current_line(64, ng0);
    t2 = (t0 + 2720);
    t3 = (t0 + 2256U);
    t4 = (t0 + 1192U);
    t6 = *((char **)t4);
    memcpy(t17, t6, 32U);
    t4 = (t0 + 6528U);
    ieee_p_3564397177_sub_1281154728_91900896(IEEE_P_3564397177, t2, t3, t17, t4, (unsigned char)0, 0);
    xsi_set_current_line(64, ng0);
    t2 = (t0 + 2720);
    t3 = (t0 + 2256U);
    t4 = (t0 + 1352U);
    t6 = *((char **)t4);
    memcpy(t18, t6, 32U);
    t4 = (t0 + 6544U);
    ieee_p_3564397177_sub_1281154728_91900896(IEEE_P_3564397177, t2, t3, t18, t4, (unsigned char)0, 0);
    xsi_set_current_line(64, ng0);
    t2 = (t0 + 2720);
    t3 = (t0 + 2256U);
    t4 = (t0 + 6892);
    t7 = (t5 + 0U);
    t11 = (t7 + 0U);
    *((int *)t11) = 1;
    t11 = (t7 + 4U);
    *((int *)t11) = 8;
    t11 = (t7 + 8U);
    *((int *)t11) = 1;
    t8 = (8 - 1);
    t9 = (t8 * 1);
    t9 = (t9 + 1);
    t11 = (t7 + 12U);
    *((unsigned int *)t11) = t9;
    std_textio_write7(STD_TEXTIO, t2, t3, t4, t5, (unsigned char)0, 0);
    xsi_set_current_line(64, ng0);
    t2 = (t0 + 2720);
    t3 = (t0 + 1976U);
    t4 = (t0 + 2256U);
    std_textio_writeline(STD_TEXTIO, t2, t3, t4);
    xsi_set_current_line(67, ng0);
    t2 = (t0 + 6900);
    t4 = (t0 + 4168);
    t6 = (t4 + 56U);
    t7 = *((char **)t6);
    t11 = (t7 + 56U);
    t12 = *((char **)t11);
    memcpy(t12, t2, 32U);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(68, ng0);
    t2 = (t0 + 6932);
    t4 = (t0 + 4232);
    t6 = (t4 + 56U);
    t7 = *((char **)t6);
    t11 = (t7 + 56U);
    t12 = *((char **)t11);
    memcpy(t12, t2, 32U);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(69, ng0);
    t10 = (100 * 1000LL);
    t2 = (t0 + 2720);
    xsi_process_wait(t2, t10);

LAB22:    *((char **)t1) = &&LAB23;
    goto LAB1;

LAB17:    goto LAB16;

LAB19:    goto LAB17;

LAB20:    xsi_set_current_line(70, ng0);
    t2 = (t0 + 2720);
    t3 = (t0 + 2256U);
    t4 = (t0 + 1032U);
    t6 = *((char **)t4);
    memcpy(t19, t6, 32U);
    t4 = (t0 + 6512U);
    ieee_p_3564397177_sub_1281154728_91900896(IEEE_P_3564397177, t2, t3, t19, t4, (unsigned char)0, 0);
    xsi_set_current_line(70, ng0);
    t2 = (t0 + 2720);
    t3 = (t0 + 2256U);
    t4 = (t0 + 1192U);
    t6 = *((char **)t4);
    memcpy(t20, t6, 32U);
    t4 = (t0 + 6528U);
    ieee_p_3564397177_sub_1281154728_91900896(IEEE_P_3564397177, t2, t3, t20, t4, (unsigned char)0, 0);
    xsi_set_current_line(70, ng0);
    t2 = (t0 + 2720);
    t3 = (t0 + 2256U);
    t4 = (t0 + 1352U);
    t6 = *((char **)t4);
    memcpy(t21, t6, 32U);
    t4 = (t0 + 6544U);
    ieee_p_3564397177_sub_1281154728_91900896(IEEE_P_3564397177, t2, t3, t21, t4, (unsigned char)0, 0);
    xsi_set_current_line(70, ng0);
    t2 = (t0 + 2720);
    t3 = (t0 + 2256U);
    t4 = (t0 + 6964);
    t7 = (t5 + 0U);
    t11 = (t7 + 0U);
    *((int *)t11) = 1;
    t11 = (t7 + 4U);
    *((int *)t11) = 8;
    t11 = (t7 + 8U);
    *((int *)t11) = 1;
    t8 = (8 - 1);
    t9 = (t8 * 1);
    t9 = (t9 + 1);
    t11 = (t7 + 12U);
    *((unsigned int *)t11) = t9;
    std_textio_write7(STD_TEXTIO, t2, t3, t4, t5, (unsigned char)0, 0);
    xsi_set_current_line(70, ng0);
    t2 = (t0 + 2720);
    t3 = (t0 + 1976U);
    t4 = (t0 + 2256U);
    std_textio_writeline(STD_TEXTIO, t2, t3, t4);
    xsi_set_current_line(73, ng0);
    t2 = (t0 + 6972);
    t4 = (t0 + 4168);
    t6 = (t4 + 56U);
    t7 = *((char **)t6);
    t11 = (t7 + 56U);
    t12 = *((char **)t11);
    memcpy(t12, t2, 32U);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(74, ng0);
    t2 = (t0 + 7004);
    t4 = (t0 + 4232);
    t6 = (t4 + 56U);
    t7 = *((char **)t6);
    t11 = (t7 + 56U);
    t12 = *((char **)t11);
    memcpy(t12, t2, 32U);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(75, ng0);
    t10 = (100 * 1000LL);
    t2 = (t0 + 2720);
    xsi_process_wait(t2, t10);

LAB26:    *((char **)t1) = &&LAB27;
    goto LAB1;

LAB21:    goto LAB20;

LAB23:    goto LAB21;

LAB24:    xsi_set_current_line(76, ng0);
    t2 = (t0 + 2720);
    t3 = (t0 + 2256U);
    t4 = (t0 + 1032U);
    t6 = *((char **)t4);
    memcpy(t22, t6, 32U);
    t4 = (t0 + 6512U);
    ieee_p_3564397177_sub_1281154728_91900896(IEEE_P_3564397177, t2, t3, t22, t4, (unsigned char)0, 0);
    xsi_set_current_line(76, ng0);
    t2 = (t0 + 2720);
    t3 = (t0 + 2256U);
    t4 = (t0 + 1192U);
    t6 = *((char **)t4);
    memcpy(t23, t6, 32U);
    t4 = (t0 + 6528U);
    ieee_p_3564397177_sub_1281154728_91900896(IEEE_P_3564397177, t2, t3, t23, t4, (unsigned char)0, 0);
    xsi_set_current_line(76, ng0);
    t2 = (t0 + 2720);
    t3 = (t0 + 2256U);
    t4 = (t0 + 1352U);
    t6 = *((char **)t4);
    memcpy(t24, t6, 32U);
    t4 = (t0 + 6544U);
    ieee_p_3564397177_sub_1281154728_91900896(IEEE_P_3564397177, t2, t3, t24, t4, (unsigned char)0, 0);
    xsi_set_current_line(76, ng0);
    t2 = (t0 + 2720);
    t3 = (t0 + 2256U);
    t4 = (t0 + 7036);
    t7 = (t5 + 0U);
    t11 = (t7 + 0U);
    *((int *)t11) = 1;
    t11 = (t7 + 4U);
    *((int *)t11) = 8;
    t11 = (t7 + 8U);
    *((int *)t11) = 1;
    t8 = (8 - 1);
    t9 = (t8 * 1);
    t9 = (t9 + 1);
    t11 = (t7 + 12U);
    *((unsigned int *)t11) = t9;
    std_textio_write7(STD_TEXTIO, t2, t3, t4, t5, (unsigned char)0, 0);
    xsi_set_current_line(76, ng0);
    t2 = (t0 + 2720);
    t3 = (t0 + 1976U);
    t4 = (t0 + 2256U);
    std_textio_writeline(STD_TEXTIO, t2, t3, t4);
    xsi_set_current_line(78, ng0);
    t2 = (t0 + 7044);
    t4 = (t0 + 4168);
    t6 = (t4 + 56U);
    t7 = *((char **)t6);
    t11 = (t7 + 56U);
    t12 = *((char **)t11);
    memcpy(t12, t2, 32U);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(79, ng0);
    t2 = (t0 + 7076);
    t4 = (t0 + 4232);
    t6 = (t4 + 56U);
    t7 = *((char **)t6);
    t11 = (t7 + 56U);
    t12 = *((char **)t11);
    memcpy(t12, t2, 32U);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(80, ng0);
    t10 = (100 * 1000LL);
    t2 = (t0 + 2720);
    xsi_process_wait(t2, t10);

LAB30:    *((char **)t1) = &&LAB31;
    goto LAB1;

LAB25:    goto LAB24;

LAB27:    goto LAB25;

LAB28:    xsi_set_current_line(81, ng0);
    t2 = (t0 + 2720);
    t3 = (t0 + 2256U);
    t4 = (t0 + 1032U);
    t6 = *((char **)t4);
    memcpy(t25, t6, 32U);
    t4 = (t0 + 6512U);
    ieee_p_3564397177_sub_1281154728_91900896(IEEE_P_3564397177, t2, t3, t25, t4, (unsigned char)0, 0);
    xsi_set_current_line(81, ng0);
    t2 = (t0 + 2720);
    t3 = (t0 + 2256U);
    t4 = (t0 + 1192U);
    t6 = *((char **)t4);
    memcpy(t26, t6, 32U);
    t4 = (t0 + 6528U);
    ieee_p_3564397177_sub_1281154728_91900896(IEEE_P_3564397177, t2, t3, t26, t4, (unsigned char)0, 0);
    xsi_set_current_line(81, ng0);
    t2 = (t0 + 2720);
    t3 = (t0 + 2256U);
    t4 = (t0 + 1352U);
    t6 = *((char **)t4);
    memcpy(t27, t6, 32U);
    t4 = (t0 + 6544U);
    ieee_p_3564397177_sub_1281154728_91900896(IEEE_P_3564397177, t2, t3, t27, t4, (unsigned char)0, 0);
    xsi_set_current_line(81, ng0);
    t2 = (t0 + 2720);
    t3 = (t0 + 2256U);
    t4 = (t0 + 7108);
    t7 = (t5 + 0U);
    t11 = (t7 + 0U);
    *((int *)t11) = 1;
    t11 = (t7 + 4U);
    *((int *)t11) = 8;
    t11 = (t7 + 8U);
    *((int *)t11) = 1;
    t8 = (8 - 1);
    t9 = (t8 * 1);
    t9 = (t9 + 1);
    t11 = (t7 + 12U);
    *((unsigned int *)t11) = t9;
    std_textio_write7(STD_TEXTIO, t2, t3, t4, t5, (unsigned char)0, 0);
    xsi_set_current_line(81, ng0);
    t2 = (t0 + 2720);
    t3 = (t0 + 1976U);
    t4 = (t0 + 2256U);
    std_textio_writeline(STD_TEXTIO, t2, t3, t4);
    xsi_set_current_line(84, ng0);
    t2 = (t0 + 7116);
    t4 = (t0 + 4168);
    t6 = (t4 + 56U);
    t7 = *((char **)t6);
    t11 = (t7 + 56U);
    t12 = *((char **)t11);
    memcpy(t12, t2, 32U);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(85, ng0);
    t2 = (t0 + 7148);
    t4 = (t0 + 4232);
    t6 = (t4 + 56U);
    t7 = *((char **)t6);
    t11 = (t7 + 56U);
    t12 = *((char **)t11);
    memcpy(t12, t2, 32U);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(86, ng0);
    t10 = (100 * 1000LL);
    t2 = (t0 + 2720);
    xsi_process_wait(t2, t10);

LAB34:    *((char **)t1) = &&LAB35;
    goto LAB1;

LAB29:    goto LAB28;

LAB31:    goto LAB29;

LAB32:    xsi_set_current_line(87, ng0);
    t2 = (t0 + 2720);
    t3 = (t0 + 2256U);
    t4 = (t0 + 1032U);
    t6 = *((char **)t4);
    memcpy(t28, t6, 32U);
    t4 = (t0 + 6512U);
    ieee_p_3564397177_sub_1281154728_91900896(IEEE_P_3564397177, t2, t3, t28, t4, (unsigned char)0, 0);
    xsi_set_current_line(87, ng0);
    t2 = (t0 + 2720);
    t3 = (t0 + 2256U);
    t4 = (t0 + 1192U);
    t6 = *((char **)t4);
    memcpy(t29, t6, 32U);
    t4 = (t0 + 6528U);
    ieee_p_3564397177_sub_1281154728_91900896(IEEE_P_3564397177, t2, t3, t29, t4, (unsigned char)0, 0);
    xsi_set_current_line(87, ng0);
    t2 = (t0 + 2720);
    t3 = (t0 + 2256U);
    t4 = (t0 + 1352U);
    t6 = *((char **)t4);
    memcpy(t30, t6, 32U);
    t4 = (t0 + 6544U);
    ieee_p_3564397177_sub_1281154728_91900896(IEEE_P_3564397177, t2, t3, t30, t4, (unsigned char)0, 0);
    xsi_set_current_line(87, ng0);
    t2 = (t0 + 2720);
    t3 = (t0 + 2256U);
    t4 = (t0 + 7180);
    t7 = (t5 + 0U);
    t11 = (t7 + 0U);
    *((int *)t11) = 1;
    t11 = (t7 + 4U);
    *((int *)t11) = 8;
    t11 = (t7 + 8U);
    *((int *)t11) = 1;
    t8 = (8 - 1);
    t9 = (t8 * 1);
    t9 = (t9 + 1);
    t11 = (t7 + 12U);
    *((unsigned int *)t11) = t9;
    std_textio_write7(STD_TEXTIO, t2, t3, t4, t5, (unsigned char)0, 0);
    xsi_set_current_line(87, ng0);
    t2 = (t0 + 2720);
    t3 = (t0 + 1976U);
    t4 = (t0 + 2256U);
    std_textio_writeline(STD_TEXTIO, t2, t3, t4);
    xsi_set_current_line(90, ng0);
    t2 = (t0 + 7188);
    t4 = (t0 + 4168);
    t6 = (t4 + 56U);
    t7 = *((char **)t6);
    t11 = (t7 + 56U);
    t12 = *((char **)t11);
    memcpy(t12, t2, 32U);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(91, ng0);
    t2 = (t0 + 7220);
    t4 = (t0 + 4232);
    t6 = (t4 + 56U);
    t7 = *((char **)t6);
    t11 = (t7 + 56U);
    t12 = *((char **)t11);
    memcpy(t12, t2, 32U);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(92, ng0);
    t10 = (100 * 1000LL);
    t2 = (t0 + 2720);
    xsi_process_wait(t2, t10);

LAB38:    *((char **)t1) = &&LAB39;
    goto LAB1;

LAB33:    goto LAB32;

LAB35:    goto LAB33;

LAB36:    xsi_set_current_line(93, ng0);
    t2 = (t0 + 2720);
    t3 = (t0 + 2256U);
    t4 = (t0 + 1032U);
    t6 = *((char **)t4);
    memcpy(t31, t6, 32U);
    t4 = (t0 + 6512U);
    ieee_p_3564397177_sub_1281154728_91900896(IEEE_P_3564397177, t2, t3, t31, t4, (unsigned char)0, 0);
    xsi_set_current_line(93, ng0);
    t2 = (t0 + 2720);
    t3 = (t0 + 2256U);
    t4 = (t0 + 1192U);
    t6 = *((char **)t4);
    memcpy(t32, t6, 32U);
    t4 = (t0 + 6528U);
    ieee_p_3564397177_sub_1281154728_91900896(IEEE_P_3564397177, t2, t3, t32, t4, (unsigned char)0, 0);
    xsi_set_current_line(93, ng0);
    t2 = (t0 + 2720);
    t3 = (t0 + 2256U);
    t4 = (t0 + 1352U);
    t6 = *((char **)t4);
    memcpy(t33, t6, 32U);
    t4 = (t0 + 6544U);
    ieee_p_3564397177_sub_1281154728_91900896(IEEE_P_3564397177, t2, t3, t33, t4, (unsigned char)0, 0);
    xsi_set_current_line(93, ng0);
    t2 = (t0 + 2720);
    t3 = (t0 + 2256U);
    t4 = (t0 + 7252);
    t7 = (t5 + 0U);
    t11 = (t7 + 0U);
    *((int *)t11) = 1;
    t11 = (t7 + 4U);
    *((int *)t11) = 8;
    t11 = (t7 + 8U);
    *((int *)t11) = 1;
    t8 = (8 - 1);
    t9 = (t8 * 1);
    t9 = (t9 + 1);
    t11 = (t7 + 12U);
    *((unsigned int *)t11) = t9;
    std_textio_write7(STD_TEXTIO, t2, t3, t4, t5, (unsigned char)0, 0);
    xsi_set_current_line(93, ng0);
    t2 = (t0 + 2720);
    t3 = (t0 + 1976U);
    t4 = (t0 + 2256U);
    std_textio_writeline(STD_TEXTIO, t2, t3, t4);
    xsi_set_current_line(96, ng0);
    t2 = (t0 + 7260);
    t4 = (t0 + 4168);
    t6 = (t4 + 56U);
    t7 = *((char **)t6);
    t11 = (t7 + 56U);
    t12 = *((char **)t11);
    memcpy(t12, t2, 32U);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(97, ng0);
    t2 = (t0 + 7292);
    t4 = (t0 + 4232);
    t6 = (t4 + 56U);
    t7 = *((char **)t6);
    t11 = (t7 + 56U);
    t12 = *((char **)t11);
    memcpy(t12, t2, 32U);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(98, ng0);
    t10 = (100 * 1000LL);
    t2 = (t0 + 2720);
    xsi_process_wait(t2, t10);

LAB42:    *((char **)t1) = &&LAB43;
    goto LAB1;

LAB37:    goto LAB36;

LAB39:    goto LAB37;

LAB40:    xsi_set_current_line(99, ng0);
    t2 = (t0 + 2720);
    t3 = (t0 + 2256U);
    t4 = (t0 + 1032U);
    t6 = *((char **)t4);
    memcpy(t34, t6, 32U);
    t4 = (t0 + 6512U);
    ieee_p_3564397177_sub_1281154728_91900896(IEEE_P_3564397177, t2, t3, t34, t4, (unsigned char)0, 0);
    xsi_set_current_line(99, ng0);
    t2 = (t0 + 2720);
    t3 = (t0 + 2256U);
    t4 = (t0 + 1192U);
    t6 = *((char **)t4);
    memcpy(t35, t6, 32U);
    t4 = (t0 + 6528U);
    ieee_p_3564397177_sub_1281154728_91900896(IEEE_P_3564397177, t2, t3, t35, t4, (unsigned char)0, 0);
    xsi_set_current_line(99, ng0);
    t2 = (t0 + 2720);
    t3 = (t0 + 2256U);
    t4 = (t0 + 1352U);
    t6 = *((char **)t4);
    memcpy(t36, t6, 32U);
    t4 = (t0 + 6544U);
    ieee_p_3564397177_sub_1281154728_91900896(IEEE_P_3564397177, t2, t3, t36, t4, (unsigned char)0, 0);
    xsi_set_current_line(99, ng0);
    t2 = (t0 + 2720);
    t3 = (t0 + 2256U);
    t4 = (t0 + 7324);
    t7 = (t5 + 0U);
    t11 = (t7 + 0U);
    *((int *)t11) = 1;
    t11 = (t7 + 4U);
    *((int *)t11) = 8;
    t11 = (t7 + 8U);
    *((int *)t11) = 1;
    t8 = (8 - 1);
    t9 = (t8 * 1);
    t9 = (t9 + 1);
    t11 = (t7 + 12U);
    *((unsigned int *)t11) = t9;
    std_textio_write7(STD_TEXTIO, t2, t3, t4, t5, (unsigned char)0, 0);
    xsi_set_current_line(99, ng0);
    t2 = (t0 + 2720);
    t3 = (t0 + 1976U);
    t4 = (t0 + 2256U);
    std_textio_writeline(STD_TEXTIO, t2, t3, t4);
    xsi_set_current_line(102, ng0);
    t2 = (t0 + 7332);
    t4 = (t0 + 4168);
    t6 = (t4 + 56U);
    t7 = *((char **)t6);
    t11 = (t7 + 56U);
    t12 = *((char **)t11);
    memcpy(t12, t2, 32U);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(103, ng0);
    t2 = (t0 + 7364);
    t4 = (t0 + 4232);
    t6 = (t4 + 56U);
    t7 = *((char **)t6);
    t11 = (t7 + 56U);
    t12 = *((char **)t11);
    memcpy(t12, t2, 32U);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(104, ng0);
    t10 = (100 * 1000LL);
    t2 = (t0 + 2720);
    xsi_process_wait(t2, t10);

LAB46:    *((char **)t1) = &&LAB47;
    goto LAB1;

LAB41:    goto LAB40;

LAB43:    goto LAB41;

LAB44:    xsi_set_current_line(105, ng0);
    t2 = (t0 + 2720);
    t3 = (t0 + 2256U);
    t4 = (t0 + 1032U);
    t6 = *((char **)t4);
    memcpy(t37, t6, 32U);
    t4 = (t0 + 6512U);
    ieee_p_3564397177_sub_1281154728_91900896(IEEE_P_3564397177, t2, t3, t37, t4, (unsigned char)0, 0);
    xsi_set_current_line(105, ng0);
    t2 = (t0 + 2720);
    t3 = (t0 + 2256U);
    t4 = (t0 + 1192U);
    t6 = *((char **)t4);
    memcpy(t38, t6, 32U);
    t4 = (t0 + 6528U);
    ieee_p_3564397177_sub_1281154728_91900896(IEEE_P_3564397177, t2, t3, t38, t4, (unsigned char)0, 0);
    xsi_set_current_line(105, ng0);
    t2 = (t0 + 2720);
    t3 = (t0 + 2256U);
    t4 = (t0 + 1352U);
    t6 = *((char **)t4);
    memcpy(t39, t6, 32U);
    t4 = (t0 + 6544U);
    ieee_p_3564397177_sub_1281154728_91900896(IEEE_P_3564397177, t2, t3, t39, t4, (unsigned char)0, 0);
    xsi_set_current_line(105, ng0);
    t2 = (t0 + 2720);
    t3 = (t0 + 2256U);
    t4 = (t0 + 7396);
    t7 = (t5 + 0U);
    t11 = (t7 + 0U);
    *((int *)t11) = 1;
    t11 = (t7 + 4U);
    *((int *)t11) = 8;
    t11 = (t7 + 8U);
    *((int *)t11) = 1;
    t8 = (8 - 1);
    t9 = (t8 * 1);
    t9 = (t9 + 1);
    t11 = (t7 + 12U);
    *((unsigned int *)t11) = t9;
    std_textio_write7(STD_TEXTIO, t2, t3, t4, t5, (unsigned char)0, 0);
    xsi_set_current_line(105, ng0);
    t2 = (t0 + 2720);
    t3 = (t0 + 1976U);
    t4 = (t0 + 2256U);
    std_textio_writeline(STD_TEXTIO, t2, t3, t4);
    xsi_set_current_line(108, ng0);
    t2 = (t0 + 7404);
    t4 = (t0 + 4168);
    t6 = (t4 + 56U);
    t7 = *((char **)t6);
    t11 = (t7 + 56U);
    t12 = *((char **)t11);
    memcpy(t12, t2, 32U);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(109, ng0);
    t2 = (t0 + 7436);
    t4 = (t0 + 4232);
    t6 = (t4 + 56U);
    t7 = *((char **)t6);
    t11 = (t7 + 56U);
    t12 = *((char **)t11);
    memcpy(t12, t2, 32U);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(110, ng0);
    t10 = (100 * 1000LL);
    t2 = (t0 + 2720);
    xsi_process_wait(t2, t10);

LAB50:    *((char **)t1) = &&LAB51;
    goto LAB1;

LAB45:    goto LAB44;

LAB47:    goto LAB45;

LAB48:    xsi_set_current_line(111, ng0);
    t2 = (t0 + 2720);
    t3 = (t0 + 2256U);
    t4 = (t0 + 1032U);
    t6 = *((char **)t4);
    memcpy(t40, t6, 32U);
    t4 = (t0 + 6512U);
    ieee_p_3564397177_sub_1281154728_91900896(IEEE_P_3564397177, t2, t3, t40, t4, (unsigned char)0, 0);
    xsi_set_current_line(111, ng0);
    t2 = (t0 + 2720);
    t3 = (t0 + 2256U);
    t4 = (t0 + 1192U);
    t6 = *((char **)t4);
    memcpy(t41, t6, 32U);
    t4 = (t0 + 6528U);
    ieee_p_3564397177_sub_1281154728_91900896(IEEE_P_3564397177, t2, t3, t41, t4, (unsigned char)0, 0);
    xsi_set_current_line(111, ng0);
    t2 = (t0 + 2720);
    t3 = (t0 + 2256U);
    t4 = (t0 + 1352U);
    t6 = *((char **)t4);
    memcpy(t42, t6, 32U);
    t4 = (t0 + 6544U);
    ieee_p_3564397177_sub_1281154728_91900896(IEEE_P_3564397177, t2, t3, t42, t4, (unsigned char)0, 0);
    xsi_set_current_line(111, ng0);
    t2 = (t0 + 2720);
    t3 = (t0 + 2256U);
    t4 = (t0 + 7468);
    t7 = (t5 + 0U);
    t11 = (t7 + 0U);
    *((int *)t11) = 1;
    t11 = (t7 + 4U);
    *((int *)t11) = 8;
    t11 = (t7 + 8U);
    *((int *)t11) = 1;
    t8 = (8 - 1);
    t9 = (t8 * 1);
    t9 = (t9 + 1);
    t11 = (t7 + 12U);
    *((unsigned int *)t11) = t9;
    std_textio_write7(STD_TEXTIO, t2, t3, t4, t5, (unsigned char)0, 0);
    xsi_set_current_line(111, ng0);
    t2 = (t0 + 2720);
    t3 = (t0 + 1976U);
    t4 = (t0 + 2256U);
    std_textio_writeline(STD_TEXTIO, t2, t3, t4);
    xsi_set_current_line(114, ng0);
    t2 = (t0 + 7476);
    t4 = (t0 + 4168);
    t6 = (t4 + 56U);
    t7 = *((char **)t6);
    t11 = (t7 + 56U);
    t12 = *((char **)t11);
    memcpy(t12, t2, 32U);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(115, ng0);
    t2 = (t0 + 7508);
    t4 = (t0 + 4232);
    t6 = (t4 + 56U);
    t7 = *((char **)t6);
    t11 = (t7 + 56U);
    t12 = *((char **)t11);
    memcpy(t12, t2, 32U);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(116, ng0);
    t10 = (100 * 1000LL);
    t2 = (t0 + 2720);
    xsi_process_wait(t2, t10);

LAB54:    *((char **)t1) = &&LAB55;
    goto LAB1;

LAB49:    goto LAB48;

LAB51:    goto LAB49;

LAB52:    xsi_set_current_line(117, ng0);
    t2 = (t0 + 2720);
    t3 = (t0 + 2256U);
    t4 = (t0 + 1032U);
    t6 = *((char **)t4);
    memcpy(t43, t6, 32U);
    t4 = (t0 + 6512U);
    ieee_p_3564397177_sub_1281154728_91900896(IEEE_P_3564397177, t2, t3, t43, t4, (unsigned char)0, 0);
    xsi_set_current_line(117, ng0);
    t2 = (t0 + 2720);
    t3 = (t0 + 2256U);
    t4 = (t0 + 1192U);
    t6 = *((char **)t4);
    memcpy(t44, t6, 32U);
    t4 = (t0 + 6528U);
    ieee_p_3564397177_sub_1281154728_91900896(IEEE_P_3564397177, t2, t3, t44, t4, (unsigned char)0, 0);
    xsi_set_current_line(117, ng0);
    t2 = (t0 + 2720);
    t3 = (t0 + 2256U);
    t4 = (t0 + 1352U);
    t6 = *((char **)t4);
    memcpy(t45, t6, 32U);
    t4 = (t0 + 6544U);
    ieee_p_3564397177_sub_1281154728_91900896(IEEE_P_3564397177, t2, t3, t45, t4, (unsigned char)0, 0);
    xsi_set_current_line(117, ng0);
    t2 = (t0 + 2720);
    t3 = (t0 + 2256U);
    t4 = (t0 + 7540);
    t7 = (t5 + 0U);
    t11 = (t7 + 0U);
    *((int *)t11) = 1;
    t11 = (t7 + 4U);
    *((int *)t11) = 8;
    t11 = (t7 + 8U);
    *((int *)t11) = 1;
    t8 = (8 - 1);
    t9 = (t8 * 1);
    t9 = (t9 + 1);
    t11 = (t7 + 12U);
    *((unsigned int *)t11) = t9;
    std_textio_write7(STD_TEXTIO, t2, t3, t4, t5, (unsigned char)0, 0);
    xsi_set_current_line(117, ng0);
    t2 = (t0 + 2720);
    t3 = (t0 + 1976U);
    t4 = (t0 + 2256U);
    std_textio_writeline(STD_TEXTIO, t2, t3, t4);
    xsi_set_current_line(120, ng0);
    t2 = (t0 + 7548);
    t4 = (t0 + 4168);
    t6 = (t4 + 56U);
    t7 = *((char **)t6);
    t11 = (t7 + 56U);
    t12 = *((char **)t11);
    memcpy(t12, t2, 32U);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(121, ng0);
    t2 = (t0 + 7580);
    t4 = (t0 + 4232);
    t6 = (t4 + 56U);
    t7 = *((char **)t6);
    t11 = (t7 + 56U);
    t12 = *((char **)t11);
    memcpy(t12, t2, 32U);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(122, ng0);
    t10 = (100 * 1000LL);
    t2 = (t0 + 2720);
    xsi_process_wait(t2, t10);

LAB58:    *((char **)t1) = &&LAB59;
    goto LAB1;

LAB53:    goto LAB52;

LAB55:    goto LAB53;

LAB56:    xsi_set_current_line(123, ng0);
    t2 = (t0 + 2720);
    t3 = (t0 + 2256U);
    t4 = (t0 + 1032U);
    t6 = *((char **)t4);
    memcpy(t46, t6, 32U);
    t4 = (t0 + 6512U);
    ieee_p_3564397177_sub_1281154728_91900896(IEEE_P_3564397177, t2, t3, t46, t4, (unsigned char)0, 0);
    xsi_set_current_line(123, ng0);
    t2 = (t0 + 2720);
    t3 = (t0 + 2256U);
    t4 = (t0 + 1192U);
    t6 = *((char **)t4);
    memcpy(t47, t6, 32U);
    t4 = (t0 + 6528U);
    ieee_p_3564397177_sub_1281154728_91900896(IEEE_P_3564397177, t2, t3, t47, t4, (unsigned char)0, 0);
    xsi_set_current_line(123, ng0);
    t2 = (t0 + 2720);
    t3 = (t0 + 2256U);
    t4 = (t0 + 1352U);
    t6 = *((char **)t4);
    memcpy(t48, t6, 32U);
    t4 = (t0 + 6544U);
    ieee_p_3564397177_sub_1281154728_91900896(IEEE_P_3564397177, t2, t3, t48, t4, (unsigned char)0, 0);
    xsi_set_current_line(123, ng0);
    t2 = (t0 + 2720);
    t3 = (t0 + 2256U);
    t4 = (t0 + 7612);
    t7 = (t5 + 0U);
    t11 = (t7 + 0U);
    *((int *)t11) = 1;
    t11 = (t7 + 4U);
    *((int *)t11) = 8;
    t11 = (t7 + 8U);
    *((int *)t11) = 1;
    t8 = (8 - 1);
    t9 = (t8 * 1);
    t9 = (t9 + 1);
    t11 = (t7 + 12U);
    *((unsigned int *)t11) = t9;
    std_textio_write7(STD_TEXTIO, t2, t3, t4, t5, (unsigned char)0, 0);
    xsi_set_current_line(123, ng0);
    t2 = (t0 + 2720);
    t3 = (t0 + 1976U);
    t4 = (t0 + 2256U);
    std_textio_writeline(STD_TEXTIO, t2, t3, t4);
    xsi_set_current_line(126, ng0);
    t2 = (t0 + 7620);
    t4 = (t0 + 4168);
    t6 = (t4 + 56U);
    t7 = *((char **)t6);
    t11 = (t7 + 56U);
    t12 = *((char **)t11);
    memcpy(t12, t2, 32U);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(127, ng0);
    t2 = (t0 + 7652);
    t4 = (t0 + 4232);
    t6 = (t4 + 56U);
    t7 = *((char **)t6);
    t11 = (t7 + 56U);
    t12 = *((char **)t11);
    memcpy(t12, t2, 32U);
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(128, ng0);
    t10 = (100 * 1000LL);
    t2 = (t0 + 2720);
    xsi_process_wait(t2, t10);

LAB62:    *((char **)t1) = &&LAB63;
    goto LAB1;

LAB57:    goto LAB56;

LAB59:    goto LAB57;

LAB60:    xsi_set_current_line(129, ng0);
    t2 = (t0 + 2720);
    t3 = (t0 + 2256U);
    t4 = (t0 + 1032U);
    t6 = *((char **)t4);
    memcpy(t49, t6, 32U);
    t4 = (t0 + 6512U);
    ieee_p_3564397177_sub_1281154728_91900896(IEEE_P_3564397177, t2, t3, t49, t4, (unsigned char)0, 0);
    xsi_set_current_line(129, ng0);
    t2 = (t0 + 2720);
    t3 = (t0 + 2256U);
    t4 = (t0 + 1192U);
    t6 = *((char **)t4);
    memcpy(t50, t6, 32U);
    t4 = (t0 + 6528U);
    ieee_p_3564397177_sub_1281154728_91900896(IEEE_P_3564397177, t2, t3, t50, t4, (unsigned char)0, 0);
    xsi_set_current_line(129, ng0);
    t2 = (t0 + 2720);
    t3 = (t0 + 2256U);
    t4 = (t0 + 1352U);
    t6 = *((char **)t4);
    memcpy(t51, t6, 32U);
    t4 = (t0 + 6544U);
    ieee_p_3564397177_sub_1281154728_91900896(IEEE_P_3564397177, t2, t3, t51, t4, (unsigned char)0, 0);
    xsi_set_current_line(129, ng0);
    t2 = (t0 + 2720);
    t3 = (t0 + 2256U);
    t4 = (t0 + 7684);
    t7 = (t5 + 0U);
    t11 = (t7 + 0U);
    *((int *)t11) = 1;
    t11 = (t7 + 4U);
    *((int *)t11) = 8;
    t11 = (t7 + 8U);
    *((int *)t11) = 1;
    t8 = (8 - 1);
    t9 = (t8 * 1);
    t9 = (t9 + 1);
    t11 = (t7 + 12U);
    *((unsigned int *)t11) = t9;
    std_textio_write7(STD_TEXTIO, t2, t3, t4, t5, (unsigned char)0, 0);
    xsi_set_current_line(129, ng0);
    t2 = (t0 + 2720);
    t3 = (t0 + 1976U);
    t4 = (t0 + 2256U);
    std_textio_writeline(STD_TEXTIO, t2, t3, t4);
    xsi_set_current_line(132, ng0);
    t2 = (t0 + 1976U);
    std_textio_file_close(t2);
    xsi_set_current_line(133, ng0);

LAB66:    *((char **)t1) = &&LAB67;
    goto LAB1;

LAB61:    goto LAB60;

LAB63:    goto LAB61;

LAB64:    goto LAB2;

LAB65:    goto LAB64;

LAB67:    goto LAB65;

}

static void work_a_1985558087_2372691052_p_1(char *t0)
{
    char *t1;
    char *t2;
    int64 t3;
    char *t4;
    int64 t5;

LAB0:    t1 = (t0 + 3160U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(142, ng0);
    t3 = (100 * 1000LL);
    t2 = (t0 + 2968);
    xsi_process_wait(t2, t3);

LAB6:    *((char **)t1) = &&LAB7;

LAB1:    return;
LAB4:    xsi_set_current_line(144, ng0);
    t2 = (t0 + 1648U);
    t4 = *((char **)t2);
    t3 = *((int64 *)t4);
    t5 = (t3 * 10);
    t2 = (t0 + 2968);
    xsi_process_wait(t2, t5);

LAB10:    *((char **)t1) = &&LAB11;
    goto LAB1;

LAB5:    goto LAB4;

LAB7:    goto LAB5;

LAB8:    xsi_set_current_line(148, ng0);

LAB14:    *((char **)t1) = &&LAB15;
    goto LAB1;

LAB9:    goto LAB8;

LAB11:    goto LAB9;

LAB12:    goto LAB2;

LAB13:    goto LAB12;

LAB15:    goto LAB13;

}


extern void work_a_1985558087_2372691052_init()
{
	static char *pe[] = {(void *)work_a_1985558087_2372691052_p_0,(void *)work_a_1985558087_2372691052_p_1};
	xsi_register_didat("work_a_1985558087_2372691052", "isim/test_isim_beh.exe.sim/work/a_1985558087_2372691052.didat");
	xsi_register_executes(pe);
}
